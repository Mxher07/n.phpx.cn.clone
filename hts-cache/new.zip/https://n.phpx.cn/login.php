  
<!DOCTYPE html>
<html>
<head>
    <title>登录</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="css/common.css">
    <style>
        .auth-container {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 24px;
        }
        
        .logo img {
            width: 80px;
            height: 80px;
            border-radius: 20px;
        }
        
        .auth-card {
            padding: 24px;
        }
        
        .auth-footer {
            text-align: center;
            margin-top: 24px;
            color: #666;
        }
        
        .auth-footer a {
            color: var(--primary-color);
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container auth-container">
        <div class="logo">
            <img src="images/logo.png" alt="Logo">
        </div>
        
        <div class="card auth-card">
            <h2 style="text-align: center; margin-bottom: 24px;">用户登录</h2>
            
                        
                        
            <form method="POST" action="">
                <div class="input-group">
                    <label for="username">用户名</label>
                    <input type="text" id="username" name="username" required autocomplete="username">
                </div>
                
                <div class="input-group">
                    <label for="password">密码</label>
                    <input type="password" id="password" name="password" required autocomplete="current-password">
                </div>
                
                <button type="submit" name="login" class="btn">登录</button>
            </form>
            
            <div class="auth-footer">
                <p>还没有账号？<a href="register.php">立即注册</a></p>
            </div>
        </div>
    </div>
</body>
</html> 